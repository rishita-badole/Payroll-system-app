# Payroll
Android App

This is a basic Payroll App, an android based app written on java language.

It  helps in managing the Payroll Management System of a company or an organisation.

It will provide basic functionalties like Login and Sign up of the User,

It provides secure authentication and savinng data to the Google Firebase.

adding employee, generating payslip, view available employee and view latest transactions.

![rsz_screenshot_2020-04-28-13-59-41-154_comexamplepayroll](https://user-images.githubusercontent.com/51875794/81916927-2397da00-95f2-11ea-9824-b0ee0bd6131a.jpg) ![rsz_screenshot_2020-04-28-13-59-47-021_comexamplepayroll](https://user-images.githubusercontent.com/51875794/81917149-72de0a80-95f2-11ea-97a9-28476cb82979.jpg) ![Screenshot_2020-04-28-13-59-50-278_comexamplepayroll](https://user-images.githubusercontent.com/51875794/81918689-71addd00-95f4-11ea-9b32-49bff6e2d6af.jpg)

![Screenshot_2020-04-28-14-00-16-716_comexamplepayroll](https://user-images.githubusercontent.com/51875794/81918855-ade13d80-95f4-11ea-8271-1d121975f602.jpg) ![Screenshot_2020-04-28-14-00-19-919_comexamplepayroll](https://user-images.githubusercontent.com/51875794/81918896-bb96c300-95f4-11ea-8846-291310358b6e.jpg) ![rsz_screenshot_2020-05-14-03-42-07-402_comexamplepayroll](https://user-images.githubusercontent.com/51875794/81918970-d5d0a100-95f4-11ea-89e8-8a8b764b73ff.jpg)

![unnamed](https://user-images.githubusercontent.com/51875794/81919459-8474e180-95f5-11ea-83e6-3009a4f8cb2a.jpg) ![unnamed 2](https://user-images.githubusercontent.com/51875794/81919495-8e96e000-95f5-11ea-8094-211d4eb5ff9e.jpg) ![unnamed 1](https://user-images.githubusercontent.com/51875794/81919535-98204800-95f5-11ea-9e29-9beb87d5f8f4.jpg)
